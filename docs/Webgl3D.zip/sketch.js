
        globalThis.preload = async function() {
            engine = new Engine();
            player = new Player();
            const response = await fetch("./export.json");
            const data = await response.json();
            engine.loadFromObject(data,true);
        }
        globalThis.setup = function() {
            createCanvas(windowWidth, windowHeight);
            noSmooth();
            //Remove right click default behaviour
            engine.setup();
        }

        